package com.example.quest.fabricintegration;

import android.app.Application;

import com.digits.sdk.android.AuthCallback;
import com.digits.sdk.android.Digits;
import com.digits.sdk.android.DigitsAuthButton;
import com.digits.sdk.android.DigitsAuthConfig;
import com.digits.sdk.android.DigitsException;
import com.digits.sdk.android.DigitsSession;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterCore;

import io.fabric.sdk.android.Fabric;

/**
 * Created by QUEST on 5/3/2016.
 */
public class Authenticate extends Application {
    private AuthCallback authCallback;
    private static final String TWITTER_KEY = "FVD0phyWW8L0NuiXDT33lUs3Y";
    private static final String TWITTER_SECRET = "55izRIfUDs74Dk46VKFXuQzXzDkkDU2dlgTDhKNcm63tqRQhPA";
    @Override
    public void onCreate() {
        super.onCreate();
        TwitterAuthConfig authConfig = new TwitterAuthConfig(TWITTER_KEY,TWITTER_SECRET);
        Fabric.with(this,new TwitterCore(authConfig), new Digits());
        authCallback = new AuthCallback()
        {
            @Override
        public void success(DigitsSession digitsSession, String s)
            {
                //Do Something
                Digits.authenticate(authCallback,"+254");
            }
            @Override
        public void failure(DigitsException e)
            {

            }
        };
    }
    public AuthCallback getAuthCallback()
    {
        return authCallback;
    }
}
